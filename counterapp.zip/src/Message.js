import React from "react";


export function Message (props){
  return (
    <div>
    <h3>new counter with export and ++</h3>
    <h3>counter {props.Ccounter}</h3>
    </div>
    );
}