import React, {useState} from "react";
import Counter from "./counter.js";
import {Message} from "./Message.js";
function App(){
  let [count , setcount] = useState(0);
  
  return (
    <div>
   <Counter />
    <br/>
    <Message Ccounter={count} />
    <button onClick={()=> setcount(++count)}>counter</button>
   
  
   
    </div>
    );
}

export default App;