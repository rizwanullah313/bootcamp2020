import React, {useState} from "react";
import "./App.css";


function Counter(){
  let [count, setcount] = useState(0);
  let [isMorning, setMorning ] = useState(true);
  
  
  return (
    <div className={`box ${isMorning ? 'daylight' : ''}`}>
    <h3>Counter {count} </h3>
    <br/>
    <button onClick={()=> setcount(count + 1)}>Update Counter</button>
    <h3>Day time {isMorning ? 'Morning' : 'Night'}</h3>
   
   <button onClick={()=>setMorning(!isMorning)}>update day</button>
    </div>
    );
}
export default Counter;