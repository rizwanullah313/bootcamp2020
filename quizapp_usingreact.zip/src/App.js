import React from "react";
import "./styles.css";
import Questionnaire from "./components/Questionnaire";

function App() {
  return (
    <div className="App">
      <center>
        <h1>Name: RizwanUllah</h1>
        <h1 className="heading">Quiz App</h1>
      </center>
      <Questionnaire />
    </div>
  );
}

export default App;
