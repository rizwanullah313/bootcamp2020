const dataSet = [
    {
        question: "Inside which HTML element do we put the JavaScript?",
        options: [
            "<scripting>",
            "<js>",
            "<script>",
            "<javascript>"
        ],
        correct: 2
    },
    {
        question: "The external JavaScript file must contain the <script> tag.",
        options: [
            "True",
            "False",
        ],
        correct: 1
    },
    {
        question: "Where is the correct place to insert a JavaScript?",
        options: [
            "Both the <head> section and the <body> section are correct",
            "The <head> section",
            "The <body> section",

        ],
        correct: 0
    },
];

export default dataSet;