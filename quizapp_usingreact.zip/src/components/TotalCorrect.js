import React from 'react';

function TotalCorrect(props) {
    return (
         <h2 className="totalcorrect"> Correct: {props.correct} </h2>
    )
}

export default TotalCorrect;
