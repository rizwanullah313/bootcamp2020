import React from 'react'
import Question from './Question'
import AnswerList from './AnswerList'
import UserGreetings from './UserGreetings'
function QuizArea(props) {
    if(props.isFinished)
    {
        return (<UserGreetings />);
    }
    return (
        <div>
    
            <Question dataSet={props.dataSet}></Question>
            <AnswerList handleClick={props.handleClick} dataSet={props.dataSet}></AnswerList>
           
        </div>
    )
}

export default QuizArea;
