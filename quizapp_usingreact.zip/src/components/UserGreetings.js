import React from 'react'

function UserGreetings() {
    return (
        <div>
           <center> <h2 className="userGreetings">Thank You for Completing the Questionnaire--!</h2></center>
        </div>
    )
}

export default UserGreetings;
