import React from "react";

function Dinner (props){
  return (
    <div>
    <h2> hello i am interested in react and {props.next} and  {props.ad} </h2>
    </div>
    );
}
export default Dinner;