import React from "react";
import Dinner from "./dinner.js";
function App(){
  return (
    <div>
    <h3>Hello this is app.js file</h3>
    <Dinner next="node js " ad="mongodb" />
    <Dinner next="html" ad="css" />

     <Dinner next="JavaScript" ad="bootstrap" />
    </div>
    );
}
export default App