import React from "react";
import Child from "./Child.js";
import Child1 from "./Child1.js";

const Parent = (props) =>{
  return (
    <div>
    <Child name={props.name}/>
    <Child1 />
    </div>
    );
}
export default Parent;