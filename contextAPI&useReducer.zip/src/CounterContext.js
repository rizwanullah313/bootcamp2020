import React, {createContext} from "react";

const counterContext = createContext(0);

export default counterContext;
