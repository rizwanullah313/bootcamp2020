import React, {useReducer} from "react";
import counterReducer from "./CounterReducer";

const Child1 = () =>{
  let [state, dispatch] = useReducer(counterReducer,0);
  return (
    <div>
    <h3>increment using reducer: {state}</h3>
    <button onClick={()=>dispatch ('INCREMENT')}>increment</button>
    </div>
    );
}
export default Child1;