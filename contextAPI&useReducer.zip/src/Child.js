import React, {useContext} from "react";
import counterContext from "./CounterContext";

const Child = (props) =>{
  let CounterValue = useContext( counterContext);
  return (
    <div>
    <h3>This is first Child</h3>
    <h4>I am {props.name}</h4>
    <h3>counter value is : {CounterValue[0]}</h3>
    <button onClick={()=>{CounterValue[1](++CounterValue[0])}}>increment</button>
    </div>
    );
}
export default Child;